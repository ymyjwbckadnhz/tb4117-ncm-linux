TB-4117 手持热像仪（泰山派 RK3566）

系统镜像：立创官方 tspi-1m-kernel6.1-debian-3.1inch-mipi-*.img
          https://wiki.lckfb.com/zh-hans/tspi-rk3566/download-center.html

安装（板子上执行）：

    tar xzf tb4117-ncm-linux-*-aarch64.tar.gz
    cd tb4117-ncm-linux-*-aarch64
    bash install.sh

没有键盘时：插 USB 键盘用 3.1 寸屏操作，或用串口（1500000 波特率），
或者从电脑 ssh 过去执行。

源码与说明：https://github.com/ymyjwbckadnhz/tb4117-ncm-linux
